# payee-api

## Packages

---

### assets

The assets folder in a Go project is typically used to store embedded fıles that are needed by the project.

### cmd

In a Go project, the cmd folder typically contains the entry points for the executable programs that are part of the
project. Each subdirectory within cmd typically represents a different executable program, and contains a main package
that defines the entry point for that program.

For example, if you're building a web application with multiple services, you might have a cmd directory with
subdirectories for each service, such as api, worker, and scheduler. Each subdirectory would contain a main package that
defines the entry point for that service.

Using a cmd directory in this way helps to keep your project organized and makes it easy to build, test, and deploy
individual programs within your project. It also makes it clear to other developers which parts of the project are
intended to be used as standalone executables.

So, to summarize, the cmd folder is an important part of a Go project because it contains the entry points for the
executable programs that are part of the project, which makes it easier to organize and manage your project.

### internal

`internal` folder in a Go project is used to define packages that are intended for internal use only. It helps to
enforce
encapsulation, modularity, and maintain a clear separation of concerns within a project.

Actually, I aim to have two types of modules within this package. One is the packages that we will use in other
microservices as well. Develop these packages as if they were a library, such as database connection, storage
implementation, etc. The second is to contain only the packages specific to this service. For example, let's say that
only the payee service from our 10 microservices retrieves data from a third-party tool. We should implement this under
this package.

### pkg

In a Go project, the pkg folder typically contains reusable packages that can be imported and used by other projects.
The purpose of the pkg folder is to provide a centralized location for packages that are intended to be used as
standalone libraries.

For example, the executable packages for gRPC and REST under the cmd directory can call the services and repositories we
implemented under this package according to their needs.

In this case, the developer developing the gRPC service and the developer developing the REST service are fed from a
single source.

### entity

Contains generated files by SQLBoiler.

## Recent changes and reasons! (Draft for explanation will delete later!)

---

- I removed the Payee prefix almost everywhere to avoid repetitive names. You can read more about
  it [here!](https://google.github.io/styleguide/go/decisions#repetition)

- I moved `env.development.yaml` to the `assets/configs` folder to take advantage of Go's embed feature. Now we don't
  need to worry about reading local files in the executable app.

- I changed the `Config` struct and the `viper` implementation. Now, we can use `env.development.yaml` for local
  development,
  and we can read environment variables with the same `Config` struct without any issues.

**WARNING 1:** For sub-struct environment variables, we should add the prefix of the super-struct. For instance, we
should set it as APP_SERVICE_NAME instead of SERVICE_NAME.

**WARNING 2**: If we want to use an environment variable, it must be defined in `env.development.yaml`.
Otherwise, `viper` won't read that variable.

- I created a Makefile to easily start up local development tools and run scripts. If you look inside the Makefile, I
  believe it is self-descriptive.

- I made a couple of Rest conventions changes. Please read following articles!

- https://restfulapi.net/resource-naming/
- https://stackoverflow.blog/2020/03/02/best-practices-for-rest-api-design/
- https://www.ibm.com/docs/en/urbancode-release/6.1.1?topic=reference-rest-api-conventions

For instance: I changed `payee` endpoint name as `payees` because of restapi standardisations. 
