package payee

import (
	"context"
	"github.com/jmoiron/sqlx"
	"github.com/volatiletech/sqlboiler/v4/boil"
	. "github.com/volatiletech/sqlboiler/v4/queries/qm"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/entity"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/pagination"
	"go.uber.org/zap"
)

type Repository interface {
	Create(ctx context.Context, e entity.Payee) (*entity.Payee, error)
	Reads(ctx context.Context, p *pagination.Pageable) (*entity.PayeeSlice, error)
	Read(ctx context.Context, id int) (*entity.Payee, error)
	Update(ctx context.Context, e entity.Payee) (*entity.Payee, error)
	Delete(ctx context.Context, id int) error
}

func NewRepository(db *sqlx.DB, logger *zap.Logger, config *config.Config) Repository {
	return &repository{
		db:     db,
		log:    logger,
		config: config,
	}
}

type repository struct {
	db     *sqlx.DB
	log    *zap.Logger
	config *config.Config
}

func (r repository) Create(ctx context.Context, e entity.Payee) (*entity.Payee, error) {
	if err := e.Insert(ctx, r.db, boil.Infer()); err != nil {
		return nil, err
	}

	return &e, nil
}

func (r repository) Reads(ctx context.Context, pageable *pagination.Pageable) (*entity.PayeeSlice, error) {
	query := []QueryMod{
		Limit(pageable.Limit()),
		Offset(pageable.Offset()),
	}

	total, err := entity.Payees(query...).Count(ctx, r.db)
	if err != nil {
		return nil, err
	}

	pageable.TotalCount = int(total)

	all, err := entity.Payees(query...).All(ctx, r.db)
	if err != nil {
		return nil, err
	}

	return &all, nil
}

func (r repository) Read(ctx context.Context, id int) (*entity.Payee, error) {
	q := []QueryMod{
		Where("id = ?", id),
	}

	return entity.Payees(q...).One(ctx, r.db)
}

func (r repository) Update(ctx context.Context, e entity.Payee) (*entity.Payee, error) {
	if _, err := e.Update(ctx, r.db, boil.Infer()); err != nil {
		return nil, err
	}

	return &e, nil
}

func (r repository) Delete(ctx context.Context, id int) error {
	q := []QueryMod{
		Where("id = ?", id),
	}

	_, err := entity.Payees(q...).DeleteAll(ctx, r.db)

	return err
}
