package payee

import (
	"context"
	proto "gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/api/api/v1"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/pb"
	"go.uber.org/zap"
)

type GRPCService interface {
	Create(ctx context.Context, req proto.PayeeCreateRequest) (*proto.PayeeCreateResponse, error)
}

func NewGRPCService(repository Repository, logger *zap.Logger) GRPCService {
	return &grpcService{
		repository: repository,
		log:        logger,
	}
}

type grpcService struct {
	repository Repository
	log        *zap.Logger
}

func (s grpcService) Create(ctx context.Context, req proto.PayeeCreateRequest) (*proto.PayeeCreateResponse, error) {
	ent, err := s.repository.Create(ctx, pb.PayeeCreateToEntity(req))
	if err != nil {
		return nil, err
	}

	res := pb.EntityToPayeeCreate(ent)

	return res, nil
}
