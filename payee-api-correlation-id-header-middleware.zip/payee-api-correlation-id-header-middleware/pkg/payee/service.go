package payee

import (
	"context"
	"database/sql"
	"errors"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/dto"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/pagination"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/errorutils"
	"go.uber.org/zap"
)

type Service interface {
	Create(ctx context.Context, req dto.PayeeCreateRequest) (*dto.PayeeResponse, error)
	Reads(ctx context.Context, pageable *pagination.Pageable) ([]dto.PayeeResponse, error)
	Read(ctx context.Context, req dto.PayeeReadRequest) (*dto.PayeeResponse, error)
	Update(ctx context.Context, req dto.PayeeUpdateRequest) (*dto.PayeeResponse, error)
	Delete(ctx context.Context, req dto.PayeeDeleteRequest) error
}

func NewService(repository Repository, logger *zap.Logger) Service {
	return &service{
		repository: repository,
		log:        logger,
	}
}

type service struct {
	repository Repository
	log        *zap.Logger
}

func (s service) Create(ctx context.Context, req dto.PayeeCreateRequest) (*dto.PayeeResponse, error) {
	ent, err := s.repository.Create(ctx, req.ToEntity())
	if err != nil {
		return nil, err
	}

	var res dto.PayeeResponse

	res.ToResponse(ent)

	return &res, nil
}

func (s service) Reads(ctx context.Context, pageable *pagination.Pageable) ([]dto.PayeeResponse, error) {
	payeeSlice, err := s.repository.Reads(ctx, pageable)
	if err != nil {
		return nil, err
	}

	payees := make([]dto.PayeeResponse, 0, len(*payeeSlice))

	for _, pa := range *payeeSlice {
		var pr dto.PayeeResponse

		pr.ToResponse(pa)

		payees = append(payees, pr)
	}

	return payees, nil
}

func (s service) Read(ctx context.Context, req dto.PayeeReadRequest) (*dto.PayeeResponse, error) {
	ent, err := s.repository.Read(ctx, req.ID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, errorutils.New(errorutils.ErrPayeeNotFound, err)
		}

		return nil, errorutils.New(errorutils.ErrUnexpected, err)
	}

	var res dto.PayeeResponse

	res.ToResponse(ent)

	return &res, nil
}

func (s service) Update(ctx context.Context, req dto.PayeeUpdateRequest) (*dto.PayeeResponse, error) {
	ent, err := s.repository.Update(ctx, req.ToEntity())
	if err != nil {
		return nil, err
	}

	var res dto.PayeeResponse

	res.ToResponse(ent)

	return &res, nil
}

func (s service) Delete(ctx context.Context, req dto.PayeeDeleteRequest) error {
	return s.repository.Delete(ctx, req.ID)
}
