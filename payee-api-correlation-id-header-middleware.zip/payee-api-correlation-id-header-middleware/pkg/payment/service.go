package payment

import (
	"context"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/dto"
	"go.uber.org/zap"
)

type Service interface {
	Create(ctx context.Context, req dto.PayeeCreateRequest) (dto.PaymentResponse, error)
	Reads(ctx context.Context) ([]dto.PaymentResponse, error)
	Read(ctx context.Context, source string) (dto.PaymentResponse, error)
	Update(ctx context.Context, source string, req dto.PayeeUpdateRequest) (dto.PaymentResponse, error)
	Delete(ctx context.Context, req dto.PayeeDeleteRequest) error
}

func NewService(repository Repository, logger *zap.Logger) Service {
	return &service{
		repository: repository,
		log:        logger,
	}
}

type service struct {
	repository Repository
	log        *zap.Logger
}

func (s service) Create(ctx context.Context, req dto.PayeeCreateRequest) (dto.PaymentResponse, error) {
	//TODO implement me
	panic("implement me")
}

func (s service) Reads(ctx context.Context) ([]dto.PaymentResponse, error) {
	//TODO implement me
	panic("implement me")
}

func (s service) Read(ctx context.Context, source string) (dto.PaymentResponse, error) {
	//TODO implement me
	panic("implement me")
}

func (s service) Update(ctx context.Context, source string, req dto.PayeeUpdateRequest) (dto.PaymentResponse, error) {
	//TODO implement me
	panic("implement me")
}

func (s service) Delete(ctx context.Context, req dto.PayeeDeleteRequest) error {
	//TODO implement me
	panic("implement me")
}
