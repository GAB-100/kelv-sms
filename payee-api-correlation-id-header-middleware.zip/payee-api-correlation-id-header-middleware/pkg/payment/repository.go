package payment

import (
	"context"
	"github.com/jmoiron/sqlx"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/entity"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/dto"
	"go.uber.org/zap"
)

type Repository interface {
	Create(ctx context.Context, payload dto.PayeeCreateRequest) (entity.Payee, error)
	Reads(ctx context.Context, source string) (entity.PayeeSlice, error)
	Update(ctx context.Context, payload dto.PayeeUpdateRequest) (entity.Payee, error)
	Delete(ctx context.Context, source, payeeID string) error
}

func NewRepository(db *sqlx.DB, logger *zap.Logger, config *config.Config) Repository {
	return &repository{
		db:     db,
		log:    logger,
		config: config,
	}
}

type repository struct {
	db     *sqlx.DB
	log    *zap.Logger
	config *config.Config
}

func (r repository) Create(ctx context.Context, payload dto.PayeeCreateRequest) (entity.Payee, error) {
	//TODO implement me
	panic("implement me")
}

func (r repository) Reads(ctx context.Context, source string) (entity.PayeeSlice, error) {
	//TODO implement me
	panic("implement me")
}

func (r repository) Update(ctx context.Context, payload dto.PayeeUpdateRequest) (entity.Payee, error) {
	//TODO implement me
	panic("implement me")
}

func (r repository) Delete(ctx context.Context, source, payeeID string) error {
	//TODO implement me
	panic("implement me")
}
