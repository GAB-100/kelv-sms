package handler

import (
	"github.com/labstack/echo/v4"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/pkg/payment"
)

type PaymentHandler interface {
	Create() echo.HandlerFunc
	Reads() echo.HandlerFunc
	Read() echo.HandlerFunc
	Update() echo.HandlerFunc
	Delete() echo.HandlerFunc
}

func NewPayment(service payment.Service) PaymentHandler {
	return &paymentHandler{
		service: service,
	}
}

type paymentHandler struct {
	service payment.Service
}

func (h paymentHandler) Create() echo.HandlerFunc {
	//TODO implement me
	return nil
}

func (h paymentHandler) Reads() echo.HandlerFunc {
	//TODO implement me
	return nil
}

func (h paymentHandler) Read() echo.HandlerFunc {
	//TODO implement me
	return nil
}

func (h paymentHandler) Update() echo.HandlerFunc {
	//TODO implement me
	return nil
}

func (h paymentHandler) Delete() echo.HandlerFunc {
	//TODO implement me
	return nil
}
