package handler

import (
	"github.com/labstack/echo/v4"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/dto"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/pagination"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/echoutils"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/pkg/payee"
	"net/http"
)

type PayeeHandler interface {
	Create() echo.HandlerFunc
	Reads() echo.HandlerFunc
	Read() echo.HandlerFunc
	Update() echo.HandlerFunc
	Delete() echo.HandlerFunc
}

func NewPayee(service payee.Service) PayeeHandler {
	return &payeeHandler{
		service: service,
	}
}

type payeeHandler struct {
	service payee.Service
}

func (h payeeHandler) Create() echo.HandlerFunc {
	return func(ctx echo.Context) error {
		var req dto.PayeeCreateRequest
		if err := echoutils.BindAndValidate(ctx, &req); err != nil {
			return err
		}

		res, err := h.service.Create(ctx.Request().Context(), req)
		if err != nil {
			return err
		}

		return ctx.JSON(http.StatusCreated, res)
	}
}

func (h payeeHandler) Reads() echo.HandlerFunc {
	return func(ctx echo.Context) error {
		pageable := pagination.NewPagination()
		if err := echoutils.BindAndValidate(ctx, pageable); err != nil {
			return err
		}

		res, err := h.service.Reads(ctx.Request().Context(), pageable)
		if err != nil {
			return err
		}

		pageable.PaginationHeader(ctx)

		return ctx.JSON(http.StatusOK, res)
	}
}

func (h payeeHandler) Read() echo.HandlerFunc {
	return func(ctx echo.Context) error {
		var req dto.PayeeReadRequest
		if err := echoutils.BindAndValidate(ctx, &req); err != nil {
			return err
		}

		collection, err := h.service.Read(ctx.Request().Context(), req)
		if err != nil {
			return err
		}

		return ctx.JSON(http.StatusOK, collection)
	}
}

func (h payeeHandler) Update() echo.HandlerFunc {
	return func(ctx echo.Context) error {
		var req dto.PayeeUpdateRequest
		if err := echoutils.BindAndValidate(ctx, &req); err != nil {
			return err
		}

		res, err := h.service.Update(ctx.Request().Context(), req)
		if err != nil {
			return err
		}

		return ctx.JSON(http.StatusAccepted, res)
	}
}

func (h payeeHandler) Delete() echo.HandlerFunc {
	return func(ctx echo.Context) error {
		var req dto.PayeeDeleteRequest
		if err := echoutils.BindAndValidate(ctx, &req); err != nil {
			return err
		}

		err := h.service.Delete(ctx.Request().Context(), req)
		if err != nil {
			return err
		}

		return ctx.JSON(http.StatusAccepted, nil)
	}
}
