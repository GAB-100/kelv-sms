package main

import (
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/cmd/rest/handler"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/pkg/payee"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/pkg/payment"
)

func (srv *server) payeeRouter() {
	repository := payee.NewRepository(srv.db, srv.logger, srv.config)
	service := payee.NewService(repository, srv.logger)
	payeeHandler := handler.NewPayee(service)
	pgr := srv.rg.Group("/payees")

	pgr.POST("", payeeHandler.Create())
	pgr.GET("", payeeHandler.Reads())
	pgr.GET("/:id", payeeHandler.Read())
	pgr.PUT("/:id", payeeHandler.Update())
	pgr.DELETE("/:id", payeeHandler.Delete())
}

func (srv *server) paymentRouter() {
	repository := payment.NewRepository(srv.db, srv.logger, srv.config)
	service := payment.NewService(repository, srv.logger)
	paymentHandler := handler.NewPayment(service)
	pgr := srv.rg.Group("/payments")

	pgr.POST("", paymentHandler.Create())
	pgr.GET("", paymentHandler.Reads())
	pgr.GET("/:id", paymentHandler.Read())
	pgr.PUT("/:id", paymentHandler.Update())
	pgr.DELETE("/:id", paymentHandler.Delete())
}
