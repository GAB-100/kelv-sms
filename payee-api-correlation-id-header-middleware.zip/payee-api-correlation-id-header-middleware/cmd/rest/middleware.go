package main

import (
	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/errorutils"
	"strings"
)

func (srv *server) authorization() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			authHeader := c.Request().Header.Get("Authorization")
			if authHeader == "" {
				return errorutils.New(errorutils.ErrMissingAuthHeader, errorutils.ErrMissingAuthHeader)
			}

			token := strings.Replace(authHeader, "Bearer ", "", 1)
			ok, err := srv.auth.VerifyToken(c.Request().Context(), token)
			if !ok || err != nil {
				return errorutils.New(errorutils.ErrInvalidToken, err)
			}

			return next(c)
		}
	}
}

func (srv *server) correlationId() echo.MiddlewareFunc {
	return func(next echo.HandlerFunc) echo.HandlerFunc {
		return func(c echo.Context) error {
			cid := c.
				Request().Header.Get("X-Correlation-ID")
			if cid == "" {
				return errorutils.New(errorutils.ErrMissingCorrelationIDHeader, errorutils.ErrMissingCorrelationIDHeader)
			}

			if _, err := uuid.Parse(cid); err != nil {
				return errorutils.New(errorutils.ErrMissingCorrelationIDHeader, errorutils.ErrMissingCorrelationIDHeader)
			}
			return next(c)
		}
	}
}
