package main

import (
	"fmt"
	"github.com/jmoiron/sqlx"
	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/auth"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/echoutils"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/validatorutils"
	"go.uber.org/zap"
	"net/http"
)

type server struct {
	auth   auth.Client
	config *config.Config
	db     *sqlx.DB
	logger *zap.Logger
	rg     *echo.Group
}

func (srv *server) run() {
	e := echo.New()
	e.Use(
		//middleware.Recover(), // Recover from all panics to always have your server up
		middleware.Logger(),    // Log everything to stdout
		middleware.RequestID(), // Generate a request id on the HTTP response headers for identification
		middleware.CORSWithConfig(middleware.DefaultCORSConfig),
		//middleware.CSRF(), // todo enable for production
		middleware.Gzip(),
		srv.correlationId(),
	)

	e.Validator = validatorutils.NewValidator()
	e.HTTPErrorHandler = echoutils.HTTPErrorHandler

	e.GET("/alive", func(c echo.Context) error {
		return c.JSON(http.StatusOK, map[string]bool{"status": true})
	})

	srv.rg = e.Group("api/v1", srv.authorization())

	srv.payeeRouter()
	srv.paymentRouter()

	e.Logger.Fatal(e.Start(fmt.Sprintf(":%d", srv.config.App.ServicePort)))
}
