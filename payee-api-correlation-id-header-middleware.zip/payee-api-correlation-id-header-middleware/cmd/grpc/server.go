package main

import (
	"fmt"
	"github.com/jmoiron/sqlx"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/cmd/grpc/handler"
	proto "gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/api/api/v1"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/pkg/payee"
	"go.uber.org/zap"
	"google.golang.org/grpc"
	"log"
	"net"
)

type server struct {
	proto.UnimplementedPayeeServiceServer
	config  *config.Config
	db      *sqlx.DB
	logger  *zap.Logger
	service payee.Service
}

func (srv *server) run() {
	listen, err := net.Listen("tcp", fmt.Sprintf("%s:%s", srv.config.GRPC.Host, srv.config.GRPC.Port))
	if err != nil {
		log.Fatal(err)
		return
	}

	grpcSrv := grpc.NewServer()

	payeeRepository := payee.NewRepository(srv.db, srv.logger, srv.config)
	payeeService := payee.NewGRPCService(payeeRepository, srv.logger)
	h := handler.NewPayeeHandler(payeeService)

	proto.RegisterPayeeServiceServer(grpcSrv, h)

	if err := grpcSrv.Serve(listen); err != nil {
		log.Fatalln("Failed to serve:", err)
	}
}
