package main

import (
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/database"
	"go.uber.org/zap"
)

func main() {

	// initialize config
	cfg := config.New()

	// initialize logger
	logger, _ := zap.NewProduction()

	// initialize db
	db := database.New(cfg)
	defer func() {
		if err := db.Close(); err != nil {
			logger.Error("unable to close DB", zap.Error(err))
		}
	}()

	srv := &server{
		config: cfg,
		db:     db,
		logger: logger,
	}

	srv.run()

}
