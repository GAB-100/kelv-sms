package handler

import (
	"context"
	proto "gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/api/api/v1"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/pkg/payee"
)

type Handler struct {
	proto.UnimplementedPayeeServiceServer
	service payee.GRPCService
}

func NewPayeeHandler(service payee.GRPCService) *Handler {
	return &Handler{
		service: service,
	}
}

func (h *Handler) PayeeCreate(ctx context.Context, req *proto.PayeeCreateRequest) (*proto.PayeeCreateResponse, error) {
	return h.service.Create(ctx, *req)
}
