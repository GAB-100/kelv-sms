package main

import (
	"context"
	"fmt"
	"github.com/grpc-ecosystem/grpc-gateway/v2/runtime"
	proto "gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/api/api/v1"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"log"
	"net/http"
)

func main() {
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// initialize config
	cfg := config.New()

	// Register gRPC server endpoint
	// Note: Make sure the gRPC server is running properly and accessible
	mux := runtime.NewServeMux()
	opts := []grpc.DialOption{grpc.WithTransportCredentials(insecure.NewCredentials())}
	err := proto.RegisterPayeeServiceHandlerFromEndpoint(ctx, mux, fmt.Sprintf("%s:%s", cfg.GRPC.Host, cfg.GRPC.Port), opts)
	if err != nil {
		log.Fatal(err)
	}

	// Start HTTP server (and proxy calls to gRPC server endpoint)
	log.Fatal(http.ListenAndServe(":8081", mux))
}
