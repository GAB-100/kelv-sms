package pb

import (
	"fmt"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/entity"
	proto "gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/api/api/v1"
)

func PayeeCreateToEntity(pcr proto.PayeeCreateRequest) entity.Payee {
	var ent entity.Payee
	ent.FirstName.SetValid(pcr.GetFirstName())
	ent.LastName.SetValid(pcr.GetLastName())
	return ent
}

func EntityToPayeeCreate(ent *entity.Payee) *proto.PayeeCreateResponse {
	pcr := proto.PayeeCreateResponse{
		Id: fmt.Sprint(ent.ID),
	}
	return &pcr

}
