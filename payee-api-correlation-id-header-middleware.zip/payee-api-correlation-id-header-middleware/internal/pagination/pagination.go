package pagination

import (
	"fmt"
	"github.com/iancoleman/strcase"
	"github.com/labstack/echo/v4"
	"math"
	"strings"
)

// Pageable defined for pagination.
type Pageable struct {
	Page       int      `query:"page"`
	Size       int      `query:"size" validate:"omitempty,min=1,max=100"`
	Sort       string   `query:"sort"`
	Q          []string `query:"q"`
	TotalCount int
}

func (p *Pageable) Filter() {
	// todo implement filter via query params
	for _, filter := range p.Q {
		filters := strings.Split(filter, ":")
		_ = fmt.Sprintf(filters[0])
	}
}

func NewPagination() *Pageable {
	return &Pageable{Page: 0, Size: 20, Sort: "createdAt,desc", Q: []string{}, TotalCount: 0}
}

func (p *Pageable) Limit() int {
	return p.Size
}

func (p *Pageable) Skip() int {
	return p.Page * p.Size
}

func (p *Pageable) Offset() int {
	return p.Page * p.Size
}

func (p *Pageable) Order() string {
	sk, sv := p.GetSortKeyAndValue()
	return fmt.Sprintf("%s %s", strcase.ToSnake(sk), sv)
}

func (p *Pageable) HasNext() bool {
	return p.Page < p.GetTotalPage()-1
}

func (p *Pageable) GetTotalPage() int {
	return int(math.Ceil(float64(p.TotalCount) / float64(p.Size)))
}

func (p *Pageable) GetSortKeyAndValue() (string, string) {
	split := strings.Split(p.Sort, ",")
	if len(split) == 2 && (split[1] == "desc" || split[1] == "asc") {
		return split[0], split[1]
	}

	return "createdAt", "desc"
}

func (p *Pageable) GetSortKey() string {
	split := strings.Split(p.Sort, ",")

	return strcase.ToSnake(split[0])
}

func (p *Pageable) GetSortValue() string {
	sort := strings.Split(p.Sort, ",")[1]
	if strings.Contains(sort, "asc") || strings.Contains(sort, "desc") {
		return sort
	}

	return "desc"
}

const (
	HeaderLink        = "Link"
	HeaderXTotalCount = "X-Total-Count"
	HeaderXTotalPage  = "X-Total-Page"
	HeaderXHasNext    = "X-Has-Next"
)

func (p *Pageable) PaginationHeader(ctx echo.Context) (int, string) {
	url := ctx.Request().URL.Host + ctx.Request().URL.Path
	link := ""

	link += fmt.Sprintf("%s\n", p.prepareLink(url, 1, "first"))

	if p.Page < p.GetTotalPage() {
		link += fmt.Sprintf("%s,\n", p.prepareLink(url, p.Page+1, "next"))
	}

	if p.Page > 1 {
		link += fmt.Sprintf("%s,\n", p.prepareLink(url, p.Page-1, "prev"))
	}

	link += p.prepareLink(url, p.GetTotalPage(), "last")

	ctx.Response().Header().Set(HeaderLink, link)
	ctx.Response().Header().Set(HeaderXTotalCount, fmt.Sprintf("%d", p.TotalCount))
	ctx.Response().Header().Set(HeaderXTotalPage, fmt.Sprintf("%d", p.GetTotalPage()))
	ctx.Response().Header().Set(HeaderXHasNext, fmt.Sprintf("%t", p.HasNext()))

	return p.TotalCount, link
}

func (p *Pageable) prepareLink(url string, page int, relType string) string {
	sk, sv := p.GetSortKeyAndValue()

	return fmt.Sprintf("<%s?page=%d&size=%d&sort=%s,%s>; rel=\"%s\"", url, page, p.Size, sk, sv, relType)
}

func (p *Pageable) IsLast() bool {
	return p.Page == p.GetTotalPage()
}
