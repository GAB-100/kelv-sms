package auth

import (
	"context"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/errorutils"
)

type Client interface {
	VerifyToken(ctx context.Context, idToken string) (bool, error)
}

func New() Client {
	return &client{}
}

type client struct {
}

func (c client) VerifyToken(ctx context.Context, idToken string) (bool, error) {
	if len(idToken) == 0 {
		return false, errorutils.New(errorutils.ErrInvalidToken, nil)
	}
	return true, nil
}
