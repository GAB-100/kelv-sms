package validatorutils

import (
	"fmt"
	"github.com/go-playground/validator/v10"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/errorutils"
)

type customValidator struct {
	validator *validator.Validate
}

func (cv *customValidator) Validate(a any) error {
	if err := cv.validator.Struct(a); err != nil {
		for _, err := range err.(validator.ValidationErrors) {
			switch err.Tag() {
			case "required":
				return errorutils.New(errorutils.Required(err.Field()), err)
			case "max":
				return errorutils.New(errorutils.Max(err.Field()), err)
			case "min":
				return errorutils.New(errorutils.Min(err.Field()), err)
			default:
				return errorutils.New(fmt.Errorf(fmt.Sprintf("%v doesn't satisfy the constraint.", err.Field())), err)
			}
		}
	}

	return nil
}

func NewValidator() *customValidator {
	validate := validator.New()
	_ = validate.RegisterValidation("new", func(fl validator.FieldLevel) bool {
		// todo implement here new validation tag
		return true
	})

	return &customValidator{
		validator: validate,
	}
}
