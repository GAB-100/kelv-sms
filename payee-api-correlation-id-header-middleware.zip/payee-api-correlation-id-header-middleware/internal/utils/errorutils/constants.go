package errorutils

// Error Codes.
const (
	ErrCodeBadRequest                 = "req/bad-request"
	ErrCodeBinding                    = "req/binding"
	ErrCodeEmptyID                    = "req/empty-id"
	ErrCodeInvalidCorrelationID       = "auth/invalid-correlation-id"
	ErrCodeInvalidToken               = "auth/invalid-token"
	ErrCodeJSONDecode                 = "com/json-decode"
	ErrCodeJSONEncode                 = "com/json-encode"
	ErrCodeJSONMarshal                = "com/json-marshal"
	ErrCodeJSONUnmarshal              = "com/json-unmarshal"
	ErrCodeLongPayeeID                = "pay/long-payee-id"
	ErrCodeMissingAuthHeader          = "auth/missing-header"
	ErrCodeMissingCorrelationIDHeader = "auth/missing-correlation-id-header"
	ErrCodePayeeNotFound              = "pay/payee-not-found"
	ErrCodeShortPayeeID               = "pay/short-payee-id"
	ErrCodeUnexpected                 = "req/unexpected"
)
