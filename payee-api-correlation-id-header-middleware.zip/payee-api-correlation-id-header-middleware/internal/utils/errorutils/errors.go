package errorutils

import (
	"errors"
	"fmt"
	"net/http"
)

// Errors.
var (
	ErrBadRequest                 = errors.New("bad request")
	ErrBinding                    = errors.New("something went wrong during data binding")
	ErrEmptyID                    = errors.New("ID can't be empty")
	ErrInvalidCorrelationID       = errors.New("invalid correlation id")
	ErrInvalidToken               = errors.New("invalid token")
	ErrJSONDecode                 = errors.New("json decode error")
	ErrJSONEncode                 = errors.New("json encode error")
	ErrJSONMarshal                = errors.New("json marshal error")
	ErrJSONUnmarshal              = errors.New("json unmarshal error")
	ErrLongPayeeID                = errors.New("payeeId should be less then 32")
	ErrMissingAuthHeader          = errors.New("missing authorization header")
	ErrMissingCorrelationIDHeader = errors.New("missing correlation id header")
	ErrPayeeNotFound              = errors.New("payee not found")
	ErrShortPayeeID               = errors.New("payeeId should be more then 32")
	ErrUnexpected                 = errors.New("unexpected error")
)

// Code gets machine-readable error code from error.
func Code(err error) string {
	errCodeMap := map[error]string{
		ErrBadRequest:                 ErrCodeBadRequest,
		ErrBinding:                    ErrCodeBinding,
		ErrEmptyID:                    ErrCodeEmptyID,
		ErrInvalidCorrelationID:       ErrCodeInvalidCorrelationID,
		ErrInvalidToken:               ErrCodeInvalidToken,
		ErrJSONDecode:                 ErrCodeJSONDecode,
		ErrJSONEncode:                 ErrCodeJSONEncode,
		ErrJSONMarshal:                ErrCodeJSONMarshal,
		ErrJSONUnmarshal:              ErrCodeJSONUnmarshal,
		ErrLongPayeeID:                ErrCodeLongPayeeID,
		ErrMissingAuthHeader:          ErrCodeMissingAuthHeader,
		ErrMissingCorrelationIDHeader: ErrCodeMissingCorrelationIDHeader,
		ErrPayeeNotFound:              ErrCodePayeeNotFound,
		ErrShortPayeeID:               ErrCodeShortPayeeID,
		ErrUnexpected:                 ErrCodeUnexpected,
	}

	if code, ok := errCodeMap[err]; ok {
		return code
	}

	return err.Error()
}

// StatusCode gets HTTP status code from error code.
func StatusCode(code string) int {
	statusCodeMap := map[string]int{
		ErrCodeBadRequest:                 http.StatusBadRequest,
		ErrCodeBinding:                    http.StatusBadRequest,
		ErrCodeEmptyID:                    http.StatusBadRequest,
		ErrCodeInvalidCorrelationID:       http.StatusUnauthorized,
		ErrCodeInvalidToken:               http.StatusUnauthorized,
		ErrCodeJSONDecode:                 http.StatusUnprocessableEntity,
		ErrCodeJSONEncode:                 http.StatusUnprocessableEntity,
		ErrCodeJSONMarshal:                http.StatusUnprocessableEntity,
		ErrCodeJSONUnmarshal:              http.StatusUnprocessableEntity,
		ErrCodeLongPayeeID:                http.StatusBadRequest,
		ErrCodeMissingAuthHeader:          http.StatusUnauthorized,
		ErrCodeMissingCorrelationIDHeader: http.StatusUnauthorized,
		ErrCodePayeeNotFound:              http.StatusNotFound,
		ErrCodeShortPayeeID:               http.StatusBadRequest,
	}

	if status, ok := statusCodeMap[code]; ok {
		return status
	}

	return http.StatusInternalServerError
}

func Required(field string) error {
	switch field {
	case "":
		return ErrUnexpected
	}

	return fmt.Errorf(fmt.Sprintf("%s is required.", field))
}

func Max(field string) error {
	switch field {
	case "PayeeID":
		return ErrLongPayeeID
	}

	return fmt.Errorf(fmt.Sprintf("%s too long.", field))
}

func Min(field string) error {
	switch field {
	case "PayeeID":
		return ErrShortPayeeID
	}

	return fmt.Errorf(fmt.Sprintf("%s too short.", field))
}
