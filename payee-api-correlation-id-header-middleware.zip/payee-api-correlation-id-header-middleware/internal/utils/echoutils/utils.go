package echoutils

import (
	"github.com/labstack/echo/v4"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/utils/errorutils"
)

func BindAndValidate(c echo.Context, i any) error {
	if err := c.Bind(i); err != nil {
		return errorutils.New(errorutils.ErrBinding, err)
	}

	return c.Validate(i)
}

// HTTPErrorHandler custom HTTP error handler for echo framework.
func HTTPErrorHandler(err error, ctx echo.Context) {
	apiErr, ok := err.(*errorutils.APIError)
	if ok {
		err = ctx.JSON(errorutils.StatusCode(apiErr.Code), apiErr)

		if err != nil {
			ctx.Echo().Logger.Error(err)
		}

		return
	}

	code := errorutils.Code(err)
	err = ctx.JSON(errorutils.StatusCode(code), &errorutils.APIError{
		Code:    code,
		Message: err.Error(),
		Err:     err,
	})

	if err != nil {
		ctx.Echo().Logger.Error(err)
	}
}
