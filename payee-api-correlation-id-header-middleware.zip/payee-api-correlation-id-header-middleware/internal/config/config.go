package config

import (
	"bytes"
	"github.com/spf13/viper"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/assets"
	"log"
	"strings"
)

type Config struct {
	App struct {
		ServiceName    string `yaml:"service_name" mapstructure:"SERVICE_NAME"`
		ServiceVersion string `yaml:"service_version" mapstructure:"SERVICE_VERSION"`
		ServicePort    int    `yaml:"service_port" mapstructure:"SERVICE_PORT"`
		Debug          bool   `yaml:"url" mapstructure:"DEBUG"`
	} `yaml:"app" mapstructure:"APP"`

	Rest struct {
		Host string `yaml:"host" mapstructure:"HOST"`
		Port string `yaml:"port" mapstructure:"PORT"`
	} `yaml:"rest" mapstructure:"REST"`

	GRPC struct {
		Host string `yaml:"host" mapstructure:"HOST"`
		Port string `yaml:"port" mapstructure:"PORT"`
	} `yaml:"grpc" mapstructure:"GRPC"`

	DB struct {
		Driver          string `yaml:"driver" mapstructure:"DRIVER"`
		Host            string `yaml:"host" mapstructure:"HOST"`
		User            string `yaml:"user" mapstructure:"USER"`
		Password        string `yaml:"password" mapstructure:"PASSWORD"`
		Port            string `yaml:"port" mapstructure:"PORT"`
		Name            string `yaml:"name" mapstructure:"NAME"`
		Schema          string `yaml:"schema" mapstructure:"SCHEMA"`
		SSLMode         string `yaml:"ssl_mode" mapstructure:"SSL_MODE"`
		MaxOpenConn     int    `yaml:"max_open_conn" mapstructure:"MAX_OPEN_CONN"`
		MaxIdleConn     int    `yaml:"max_idle_conn" mapstructure:"MAX_IDLE_CONN"`
		ConnMaxLifetime int    `yaml:"conn_max_lifetime" mapstructure:"CONN_MAX_LIFETIME"`
		Timeout         int    `yaml:"timeout" mapstructure:"TIMEOUT"`
	} `yaml:"db" mapstructure:"DB"`

	Encryption struct {
		Salt      string `yaml:"salt" mapstructure:"SALT"`
		MinLength int    `yaml:"min_length" mapstructure:"MIN_LENGTH"`
	} `yaml:"encryption" mapstructure:"ENCRYPTION"`
}

func New() *Config {
	file, err := assets.EmbeddedFiles.ReadFile("configs/env.development.yaml")
	if err != nil {
		log.Fatal("fatal error config file: \n", err)
	}

	viper.AddConfigPath("./")
	viper.SetConfigName("env.development")
	viper.SetConfigType("yaml")
	viper.AutomaticEnv()
	viper.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))
	err = viper.ReadConfig(bytes.NewReader(file))

	if err != nil {
		log.Fatal("fatal error config file: \n", err)
	}

	var cfg Config
	err = viper.Unmarshal(&cfg)

	if err != nil {
		log.Fatal("fatal error config file: \n", err)
	}

	log.Println("Config initialize success!")

	return &cfg
}
