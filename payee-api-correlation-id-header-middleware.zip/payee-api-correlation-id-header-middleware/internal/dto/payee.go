package dto

import (
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/entity"
	"time"
)

type PayeeResponse struct {
	AccountNumber string    `json:"accountNumber"`
	BusinessName  string    `json:"businessName"`
	CreatedAt     time.Time `json:"createdAt"`
	FirstName     string    `json:"firstName"`
	ID            int       `json:"id"`
	LastName      string    `json:"lastName"`
	PayeeID       string    `json:"payeeId"`
	Reference     string    `json:"reference"`
	SortCode      string    `json:"sortCode"`
	Source        string    `json:"source"`
	TrustedPayee  bool      `json:"trustedPayee"`
}

func (pr *PayeeResponse) ToResponse(ent *entity.Payee) {
	pr.AccountNumber = ent.AccountNo
	pr.BusinessName = ent.BusinessName.String
	pr.CreatedAt = ent.CreatedAt.Time
	pr.FirstName = ent.FirstName.String
	pr.ID = ent.ID
	pr.LastName = ent.LastName.String
	pr.Reference = ent.Reference
	pr.SortCode = ent.SortCode
	pr.Source = ent.Source
	pr.TrustedPayee = ent.TrustedPayee
}

type PayeeReadRequest struct {
	ID int `param:"id" validate:"required"`
}

type PayeeDeleteRequest struct {
	ID int `json:"id"`
}

type PayeeCreateRequest struct {
	AccountNumber string `json:"accountNumber" validate:"min=8,max=8"`
	BusinessName  string `json:"businessName" validate:"max=255"`
	FirstName     string `json:"firstName" validate:"max=30"`
	LastName      string `json:"lastName" validate:"max=30"`
	PayeeID       string `json:"payeeId" validate:"min=32,max=32"`
	Reference     string `json:"reference" validate:"min=2,max=30"`
	SortCode      string `json:"sortCode" validate:"required"`
	Source        string `json:"source" validate:"required"`
	TrustedPayee  bool   `json:"trustedPayee"`
}

func (pcr *PayeeCreateRequest) ToEntity() entity.Payee {
	var ent entity.Payee

	ent.AccountNo = pcr.AccountNumber
	ent.BusinessName.SetValid(pcr.BusinessName)
	ent.CreatedAt.SetValid(time.Now())
	ent.FirstName.SetValid(pcr.FirstName)
	ent.LastName.SetValid(pcr.LastName)
	ent.Reference = pcr.Reference
	ent.SortCode = pcr.SortCode
	ent.Source = pcr.Source
	ent.TrustedPayee = pcr.TrustedPayee
	ent.UpdatedAt.SetValid(time.Now())

	return ent
}

type PayeeUpdateRequest struct {
	// path param
	ID int `param:"id" validate:"required"`
	// json payload
	AccountNumber string `json:"accountNumber" validate:"min=8,max=8"`
	BusinessName  string `json:"businessName" validate:"max=255"`
	FirstName     string `json:"firstName" validate:"max=30"`
	LastName      string `json:"lastName" validate:"max=30"`
	PayeeID       string `json:"payeeId" validate:"min=32,max=32"`
	Reference     string `json:"reference" validate:"min=2,max=30"`
	SortCode      string `json:"sortCode" validate:"required"`
	Source        string `json:"source" validate:"required"`
	TrustedPayee  bool   `json:"trustedPayee"`
}

func (pcr *PayeeUpdateRequest) ToEntity() entity.Payee {
	var ent entity.Payee
	ent.ID = pcr.ID
	ent.AccountNo = pcr.AccountNumber
	ent.BusinessName.SetValid(pcr.BusinessName)
	ent.CreatedAt.SetValid(time.Now())
	ent.FirstName.SetValid(pcr.FirstName)
	ent.LastName.SetValid(pcr.LastName)
	ent.Reference = pcr.Reference
	ent.SortCode = pcr.SortCode
	ent.Source = pcr.Source
	ent.Source = pcr.Source
	ent.TrustedPayee = pcr.TrustedPayee
	ent.UpdatedAt.SetValid(time.Now())

	return ent
}
