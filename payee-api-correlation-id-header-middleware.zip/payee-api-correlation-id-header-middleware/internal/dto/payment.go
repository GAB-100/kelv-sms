package dto

type PaymentResponse struct {
	AccountNumber  string `json:"accountNumber" validate:"min=8,max=8"`
	BusinessName   string `json:"businessName" validate:"max=255"`
	FirstName      string `json:"firstName" validate:"max=30"`
	LastName       string `json:"lastName" validate:"max=30"`
	PaymentID      string `json:"payeeId" validate:"min=32,max=32"`
	Reference      string `json:"reference" validate:"min=2,max=30"`
	SortCode       string `json:"sortCode" validate:"required"`
	TrustedPayment bool   `json:"trustedPayment"`
}

type PaymentsRequest struct {
	Source string `json:"source"`
}

type PaymentDeleteRequest struct {
	PaymentID string `json:"payeeId"`
	Source    string `json:"source"`
}

type PaymentCreateRequest struct {
	AccountNumber  string `json:"accountNumber" validate:"min=8,max=8"`
	BusinessName   string `json:"businessName" validate:"max=255"`
	FirstName      string `json:"firstName" validate:"max=30"`
	LastName       string `json:"lastName" validate:"max=30"`
	PaymentID      string `json:"payeeId" validate:"min=32,max=32"`
	Reference      string `json:"reference" validate:"min=2,max=30"`
	SortCode       string `json:"sortCode" validate:"required"`
	TrustedPayment bool   `json:"trustedPayment"`
}

type PaymentsUpdateRequest struct {
	AccountNumber  string `json:"accountNumber" validate:"min=8,max=8"`
	BusinessName   string `json:"businessName" validate:"max=255"`
	FirstName      string `json:"firstName" validate:"max=30"`
	LastName       string `json:"lastName" validate:"max=30"`
	PaymentID      string `json:"payeeId" validate:"min=32,max=32"`
	Reference      string `json:"reference" validate:"min=2,max=30"`
	SortCode       string `json:"sortCode" validate:"required"`
	TrustedPayment bool   `json:"trustedPayment"`
}
