package database

import (
	"fmt"
	"github.com/jmoiron/sqlx"
	"github.com/lib/pq"
	"gitlab.com/cynergybank/fusion-reboot-poc/backend/payee-api/internal/config"
	sqlTrace "gopkg.in/DataDog/dd-trace-go.v1/contrib/database/sql"
	sqlxTrace "gopkg.in/DataDog/dd-trace-go.v1/contrib/jmoiron/sqlx"
	"log"
	"time"
)

func New(config *config.Config) *sqlx.DB {
	sqlTrace.Register(config.DB.Driver, &pq.Driver{}, sqlTrace.WithServiceName(config.App.ServiceName))

	connStr := fmt.Sprintf(
		"host=%s port=%s user=%s dbname=%s password=%s connect_timeout=%d sslmode=%s search_path=%s",
		config.DB.Host,
		config.DB.Port,
		config.DB.User,
		config.DB.Name,
		config.DB.Password,
		config.DB.Timeout,
		config.DB.SSLMode,
		config.DB.Schema,
	)

	db, err := sqlxTrace.Connect(config.DB.Driver, connStr)
	if err != nil {
		log.Fatalf("sqlxTrace.Connect failed: %v", err)
	}

	db.SetMaxOpenConns(config.DB.MaxOpenConn)
	db.SetMaxIdleConns(config.DB.MaxIdleConn)
	db.SetConnMaxLifetime(time.Duration(config.DB.ConnMaxLifetime))

	err = db.Ping()
	if err != nil {
		log.Fatalf("db connection failed: %v", err)
	}

	return db
}
