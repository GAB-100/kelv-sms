-- auto-generated definition
create table if not exists payees
(
    id            serial
        constraint payees_pk
            primary key,
    source        varchar(32)                            not null,
    first_name    varchar(100),
    last_name     varchar(100),
    business_name varchar(255),
    sort_code     varchar(6)                             not null,
    account_no    varchar(8)                             not null,
    reference     varchar(255)                           not null,
    created_at    timestamp with time zone default now(),
    updated_at    timestamp with time zone default now(),
    trusted_payee boolean                  default false not null
);

-- auto-generated definition
create table if not exists historical_payments
(
    id            serial
        constraint historical_payments_pk
            primary key,
    source        varchar(32)              not null,
    first_name    varchar(100),
    last_name     varchar(100),
    business_name varchar(255),
    date          timestamp with time zone not null,
    sort_code     varchar(6)               not null,
    account_no    varchar(8)               not null,
    reference     varchar(100)             not null,
    amount        numeric(10, 2)           not null,
    created_at    timestamp with time zone default now()
);

create unique index if not exists historical_payments_id_uindex
    on historical_payments (id);

